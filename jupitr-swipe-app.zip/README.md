# Jupitr Swipe App

This is a React prototype of the Jupitr swipe-based travel and wellness deals app.

## How to run

1. Make sure you have Node.js and npm installed. You can download them from https://nodejs.org/

2. Open a terminal or command prompt and navigate to the project folder.

3. Run the following command to install dependencies:
```
npm install
```

4. Start the development server with:
```
npm start
```

5. Your browser will open at http://localhost:3000 displaying the app.

## Features

- Swipe left to skip deals
- Swipe right to save deals to wishlist
- View wishlist after swiping through all deals
- Restart the swipe flow

## Notes

This is a simple React app prototype for demonstration purposes.